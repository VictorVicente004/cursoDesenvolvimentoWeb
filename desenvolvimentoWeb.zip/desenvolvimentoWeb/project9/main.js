// let a = 10
// let b = 5 
// let c = 20
// let resultado = a == b
// let resultado1 = a != b
// let resultado2 = (a || b) > c
// console.log(resultado)
// console.log(resultado1)
// console.log(resultado2)

let idade = prompt('Digite sua idade: ')
let temTitulo = prompt('Tem titulo de eleitor? (s/n)')
let idadeMinima = 18

if (idade >= idadeMinima && temTitulo == 's'){
    alert('Você pode votar.')
}
else if(idade >= idadeMinima && temTitulo == 'n'){
    alert('Você pode votar e deve fazer o seu titulo de eleitor.')
}
else if (idade < idadeMinima && temTitulo == 's' || temTitulo == 'n') {
    alert('Você não tem idade suficiente para votar')
}














