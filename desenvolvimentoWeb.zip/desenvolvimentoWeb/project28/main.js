// Variavel com as imagens

const imagens = [
    "images/foto1.jpeg",
    "images/foto2.jpg",
    "images/foto3.jpg",
    "images/foto4.jpeg"    
]
let index = 0;
let imagemElemento = document.getElementById('imagens')
let botaoElemento = document.getElementById('botao')


botaoElemento.addEventListener('click', function(){
 // incremento para trocar para as outras imagens
    index++
  
  // se o numero for maior que a array imagens, trocar para index 0
    if (index >= imagens.length) {
    index = 0;
  }
    imagemElemento.src = imagens[index]
})

