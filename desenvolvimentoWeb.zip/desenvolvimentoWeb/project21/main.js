let checkButton = document.getElementById("check-button")

let ageInput = document.getElementById("age-input")

checkButton.addEventListener('click', function() {
    // Operador ternario 

    let age = ageInput.value
    let message = (age >= 18) /*OPERADOR TERNARIO*/ ? /*Se for verdadeiro*/ "You are an adult" : /*se for falso*/ "You are not an adult"
    alert(message)
  //limpar o campo após retornar o alert 
    ageInput.value = ''
})