let iniciaInput = document.getElementById("comeco");
let fimInput = document.getElementById("fim");
let saidaDiv = document.getElementById("saida");

function mostrarNumerosPares() {
    let comeco = Number(iniciaInput.value)

    let fim = Number(fimInput.value)

    let i = comeco;
    let saida = 0;

    while (i <= fim) {
        if (i % 2 == 0){
             saida = saida + i + ' '
             saidaDiv.innerHTML = saida;
        }
        i++
  }

}