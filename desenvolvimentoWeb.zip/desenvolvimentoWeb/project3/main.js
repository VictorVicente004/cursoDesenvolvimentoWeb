let firstName = prompt('Digite seu primeiro nome: ');
let lastName = prompt('Digite seu último nome: ');
let age = parseInt(prompt('Digite sua idade: '))
const age2 = 5;
//age2 = 1;
age = age + age2;

console.log(firstName);
console.log(lastName);
console.log(age);
