let fruits = ['Maça', 'Banana', 'Manga', 'Pessego', 'Laranja']

// let numberList = document.getElementById('numberList')    

for (i = 0; i < 5; i++){
    
let listItem = document.createTextNode(fruits[i])
    // Vai criar um li no html
    listItem.textContent = 'Item ' + i; 




    // textContent Vai inserir o conteúdo no Html como se fosse um texto 
//    numberList.appendChild(listItem)
    listItem.appendChild(document.createTextNode(fruits[i]))
}