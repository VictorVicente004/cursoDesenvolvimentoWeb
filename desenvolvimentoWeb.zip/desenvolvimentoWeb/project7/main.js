

let C = parseFloat(prompt('Digite a temperatura em Celsius: '))

let Fahrenheit = 32 + (C * 1.8);

alert('A temperatura em Fahrenheit é: ' + Fahrenheit.toFixed(2)) 

