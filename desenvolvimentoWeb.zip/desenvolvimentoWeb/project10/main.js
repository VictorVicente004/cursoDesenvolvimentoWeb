
let valorConta = parseFloat(prompt('Digite o valor da conta: '));
let gorjeta = parseFloat(prompt('Digite a gorjeta (decimal): '));
let valorTotal = 0;


// Primeira fórmula de resolução:
//gorjeta = (valorConta * gorjeta) /100;
//valorTotal =  valorConta + gorjeta;

// Segunda fórmula de resolução: 

valorTotal = valorTotal + valorConta;
valorTotal = valorTotal + (valorConta * gorjeta) / 100;

alert('O valor total da gorjeta é de :$' + valorTotal);


