function changeColor() {
let titleH1 = document.getElementById('changeh1')
titleH1.style.color = 'red';
}
changeColor()