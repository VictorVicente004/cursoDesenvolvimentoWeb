let firstName = prompt('Digite o seu nome: ');
// como pegar a informação e jogar no html
let greeting = 'Hello'
// o elemento é pegado pelo id que foi declaradoo no html
document.getElementById("greeting").innerHTML = greeting + ' ' + firstName;
