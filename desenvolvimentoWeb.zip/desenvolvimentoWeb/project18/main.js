function changeBackgroundColor() {
let colors = ['red', 'green', 'blue', 'pink', 'purple', 'brown', 'orange']

let randomColor = colors[Math.floor(Math.random() * colors.length)]

document.body.style.backgroundColor = randomColor
}