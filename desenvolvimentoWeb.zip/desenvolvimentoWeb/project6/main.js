let friends = ['Alan', 'Mark', 'Giulia', 'Bella', true, 10, 10.1]

console.log(friends[4])
friends[4] = 'Victor';  //Replace
console.log(friends[4])
friends[5] = 'Gustavo'; //Replace
console.log(friends[5])
friends[6] = 'Pedro'; //Replace
console.log(friends[6])
friends[7] = 'Lucas'; //Replace
console.log(friends[7])
friends[8] = 'Montin4'; // Add items
console.log(friends[8]) // Mostrar index do array