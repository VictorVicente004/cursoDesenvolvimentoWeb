let firstName = 'Victor';
let lastName = 'Vicente';

let age = 19;

console.log("Meu nome é " + firstName + ' ' +  lastName)
console.log("Eu tenho " + age + " anos.")

